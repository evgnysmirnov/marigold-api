import re
import uuid

from django.core.exceptions import ValidationError
from django.db import models

_KEY_CHAR_LENGTH_MAX = 500

class BaseModel(models.Model):
    id = models.UUIDField(
        primary_key=True, unique=True, default=uuid.uuid4, editable=False
    )
    created_at = models.DateTimeField(blank=True, auto_now_add=True)
    updated_at = models.DateTimeField(blank=True, auto_now=True)

    class Meta:
        abstract = True

    def __str__(self):
        return str(self.id)

class WithKeyBaseModel(BaseModel):
    """Model with a key field."""

    key = models.CharField(
        max_length=_KEY_CHAR_LENGTH_MAX,
        unique=True,
    )

    class Meta:
        abstract = True
        constraints = [
            models.CheckConstraint(
                check=~models.Q(key=""),
                name="%(app_label)s_%(class)s_key_not_empty",
            ),
        ]

    def __str__(self):
        return f"{self.key}"

    def clean(self):
        if self.key:
            self.key = self.key.lower()
        regex = re.compile("^[A-Za-z][A-Za-z0-9_]{3,500}$")
        if not regex.findall(self.key):
            raise ValidationError("key is incorrect")

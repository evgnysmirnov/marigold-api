from django.contrib.admin.models import (
    LogEntry,
    LogEntryManager,
    ADDITION,
    CHANGE,
    ContentType,
    DELETION,
)

class LoggingMethodMixin:

    def changed_fields(self, instance, validated_data):
        changed_data = []
        for field, value in validated_data.items():
            new_value = value
            old_value = getattr(instance, field)
            if new_value != old_value:
                field = str(field).replace("_", " ").capitalize()
                changed_data.append(field)
        return changed_data

    def construct_change_message(self, operation, serializer):
        change_message = []
        if operation == ADDITION:
            change_message.append({"added": {}})
        if operation == CHANGE:
            change_message.append(
                {
                    "changed": {
                        "fields": self.changed_fields(
                            serializer.instance, serializer.validated_data
                        ),
                    }
                }
            )
        if operation == DELETION:
            change_message.append({"deleted": {}})
        return change_message

    def log(self, operation, serializer):
        if operation == DELETION:
            instance = serializer
        else:
            instance = serializer.instance

        LogEntry.objects.log_action(
            user_id=self.request.user.id,
            content_type_id=ContentType.objects.get_for_model(instance).pk,
            object_id=instance.pk,
            object_repr=str(instance),
            action_flag=operation,
            change_message=self.construct_change_message(operation, serializer),
        )

    def _log_on_create(self, serializer):
        self.log(operation=ADDITION, serializer=serializer)

    def _log_on_update(self, serializer):
        self.log(operation=CHANGE, serializer=serializer)

    def _log_on_destroy(self, serializer):
        self.log(operation=DELETION, serializer=serializer)

class LoggingViewMixin(LoggingMethodMixin):
    def perform_create(self, serializer):
        super().perform_create(serializer)
        self._log_on_create(serializer)

    def perform_update(self, serializer):
        self._log_on_update(serializer)
        super().perform_update(serializer)

    def perform_destroy(self, instance):
        super().perform_destroy(instance)
        self._log_on_destroy(instance)

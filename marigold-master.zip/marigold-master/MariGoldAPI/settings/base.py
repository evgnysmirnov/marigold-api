import os

import environ
import logging

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',  # Use the StreamHandler to log to console
        },
    },
    'root': {
        'handlers': ['console'],  # Use the console handler for the root logger
        'level': 'INFO',
    },
}

root = environ.Path(__file__) - 3
SITE_ROOT = root()
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
env = environ.Env()
environ.Env.read_env(env_file=root(".env"))
environ.Env.read_env(env_file=root(".local_env"))

DEBUG = env.bool("DEBUG", default=True)
SECRET_KEY = env.str("SECRET_KEY")
disable_existing_loggers = False

USE_X_FORWARDED_HOST = True
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

DATA_UPLOAD_MAX_NUMBER_FIELDS = 10240
MEDIA_ROOT = root("media")
MEDIA_URL = env.str("MEDIA_URL", default="media/")
STATIC_URL = "/static/"
STATIC_ROOT = os.path.join(SITE_ROOT, "static")
STATICFILES_FINDERS = [
    "django.contrib.staticfiles.finders.FileSystemFinder",
    "django.contrib.staticfiles.finders.AppDirectoriesFinder",
]
ROOT_URLCONF = "MariGoldAPI.urls"
STATIC_DIR = os.path.join(SITE_ROOT, "static")
STATICFILES_DIRS = (os.path.join(BASE_DIR, "static"),)
WSGI_APPLICATION = "MariGoldAPI.wsgi.application"

DEFAULT_AUTO_FIELD = "django.db.models.AutoField"

TIME_ZONE = "UTC"

USE_I18N = True

USE_L10N = True

USE_TZ = True

LOGGING = {
}

JOB_WORKERS = env.str("JOB_WORKERS", default=10)

GOOGLE_APPLICATION_CREDENTIALS =os.path.join(BASE_DIR, "settings/google/marigolf-dev-01c25fca608d.json")
os.environ.setdefault('GOOGLE_APPLICATION_CREDENTIALS', GOOGLE_APPLICATION_CREDENTIALS)

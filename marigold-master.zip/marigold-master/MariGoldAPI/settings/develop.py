from .base import *

SITE_URL = env.str("SITE_URL", default="https://marigold-api-btqk4.ondigitalocean.app/")

ALLOWED_HOSTS = ["*"]
DEBUG = env.bool("DEBUG", default=True)
CACHALOT_ENABLED = env.bool("CACHALOT_ENABLED", default=False)
CACHALOT_TIMEOUT = 60 * 60 * 2
CORS_ORIGIN_ALLOW_ALL = True

if CACHALOT_ENABLED:
    CACHES = {
        "default": {
            "BACKEND": "django_redis.cache.RedisCache",
            "LOCATION": "redis://:6379/5",
            "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"},
            "KEY_PREFIX": "dev",
        }
    }

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env.str("DB_NAME", default="marigold-db"),
        "USER": env.str("DB_USER", default="doadmin"),
        "PASSWORD": env.str("DB_PASS", default="AVNS_bzuzYvef8xxtmPaGxZd"),
        "HOST": env.str(
            "DB_HOST", "marigold-dev-db-do-user-14464066-0.c.db.ondigitalocean.com"
        ),
        "PORT": env.int("DB_PORT", "25060"),
        'CONN_MAX_AGE': 0,

    }
}

# File Storage

CORS_ORIGIN_ALLOW_ALL = True

# emails backend
# EMAIL_BACKEND = "anymail.backends.mandrill.EmailBackend"


# Celery
CELERY_BROKER_URL = env.str(
    "CELERY_BROKER_URL",
    default="redis://:6379/4",
)


# Set the default storage backend
DEFAULT_FILE_STORAGE = 'storages.backends.gcloud.GoogleCloudStorage'

# Configure the Google Cloud Storage settings
GS_BUCKET_NAME = 'marigold-bucket'
GS_PROJECT_ID = 'marigolf-dev'

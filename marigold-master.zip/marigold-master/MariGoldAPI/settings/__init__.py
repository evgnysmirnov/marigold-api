from .base import *
from .project import *
from .third_party.drf import *
from .third_party.debug_toolbar import *
from .third_party.celery import *

ENVIRONMENT = env.str("ENVIRONMENT", default="local")
if ENVIRONMENT == "prod":
    from .prod import *
elif ENVIRONMENT == "develop":
    from .develop import *
elif ENVIRONMENT == "local":
    from .local import *

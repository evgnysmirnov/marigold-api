from .base import *

SITE_URL = env.str("SITE_URL", default="https://")

ALLOWED_HOSTS = ["*"]
DEBUG = env.bool("DEBUG", default=True)

CACHALOT_ENABLED = False
CACHALOT_TIMEOUT = 60 * 60 * 2

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": env.str("DB_NAME", default="MariGold"),
        "USER": env.str("DB_USER", default="postgres"),
        "PASSWORD": env.str("DB_PASS", default="cn123321"),
        "HOST": env.str("DB_HOST", "127.0.0.1"),
        "PORT": env.int("DB_PORT", "5432"),
    }
}
# File Storage
CELERY_BROKER_URL = env.str(
    "CELERY_BROKER_URL",
    default="redis://localhost:6379/4",
)

# emails
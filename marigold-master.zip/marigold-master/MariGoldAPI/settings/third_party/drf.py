from rest_framework import permissions
from MariGoldAPI.settings.third_party import drf_perrmissions_fix

permissions.AND = drf_perrmissions_fix.AND
permissions.OR = drf_perrmissions_fix.OR
permissions.NOT = drf_perrmissions_fix.NOT
permissions.BasePermission = drf_perrmissions_fix.BasePermission
permissions.DjangoModelPermissions = drf_perrmissions_fix.DjangoModelPermissions
permissions.AllowAny = drf_perrmissions_fix.AllowAny
permissions.IsAdminUser = drf_perrmissions_fix.IsAdminUser
permissions.IsAuthenticated = drf_perrmissions_fix.IsAuthenticated
permissions.IsAuthenticatedOrReadOnly = drf_perrmissions_fix.IsAuthenticatedOrReadOnly
permissions.DjangoModelPermissionsOrAnonReadOnly = (
    drf_perrmissions_fix.DjangoModelPermissionsOrAnonReadOnly
)
permissions.DjangoObjectPermissions = drf_perrmissions_fix.DjangoObjectPermissions

REST_FRAMEWORK = {
    "DEFAULT_PERMISSION_CLASSES": ("rest_framework.permissions.AllowAny",),
    "DEFAULT_FILTER_BACKENDS": ("django_filters.rest_framework.DjangoFilterBackend",),
    "EXCEPTION_HANDLER": "rest_framework.views.exception_handler",
    "DEFAULT_METADATA_CLASS": "rest_framework.metadata.SimpleMetadata",
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.LimitOffsetPagination",
    "PAGE_SIZE": 20,
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework.authentication.TokenAuthentication",
        "rest_framework.authentication.BasicAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ),
    "DEFAULT_SCHEMA_CLASS": "rest_framework.schemas.openapi.AutoSchema",
}

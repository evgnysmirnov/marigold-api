set -e
python manage.py collectstatic --noinput
gunicorn MariGoldAPI.asgi --bind=:8080 --workers=1 -k uvicorn.workers.UvicornWorker --timeout 60


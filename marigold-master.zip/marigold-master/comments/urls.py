# urls.py

from django.urls import path
from .views import CommentsList, CommentDetails, MentionsList, MentionDetails

urlpatterns = [
    path('comments/', CommentsList.as_view(), name='comments-list'),
    path('comments/<int:pk>/', CommentDetails.as_view(), name='comments-details'),
    path('mentions/', MentionsList.as_view(), name='mentions-list'),
    path('mentions/<int:pk>/', MentionDetails.as_view(), name='mentions-details'),

]

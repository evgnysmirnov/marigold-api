from django.db import models

from MariGoldAPI.abstract.base_models import BaseModel
from users.models import User


class Comment(BaseModel):
    post = models.ForeignKey('posts.Post', on_delete=models.CASCADE, related_name="related_comments")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()

    def __str__(self):
        return f"@{self.user.username} ({self.content})"


class Mention(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE, related_name='parent_comment')
    reply = models.ForeignKey(Comment, on_delete=models.CASCADE, related_name='replies')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"@{self.user} for {self.comment.content} replyed {self.reply.content}"
from django_filters import rest_framework as filters
from rest_framework import generics
from rest_framework import permissions
from rest_framework.filters import SearchFilter, OrderingFilter

from comments.models import Comment, Mention
from comments.serializers import CommentSerializer, MentionSerializer


class CommentsList(generics.ListCreateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    search_fields = ["content", ]
    ordering_fields = ("created_at",)
    ordering = ("created_at",)
    filterset_fields = ["user", "post", "parent_comment"]
    model = Comment
    queryset = model.objects.all()
    serializer_class = CommentSerializer


class CommentDetails(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = Comment
    queryset = model.objects.all()
    serializer_class = CommentSerializer


class MentionsList(generics.ListCreateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    ordering_fields = ("created_at",)
    ordering = ("created_at",)
    filterset_fields = ["user", "reply", "comment"]
    model = Mention
    queryset = model.objects.all()
    serializer_class = MentionSerializer


class MentionDetails(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = Mention
    queryset = model.objects.all()
    serializer_class = MentionSerializer

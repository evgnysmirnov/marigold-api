from django.contrib import admin

from django.contrib import admin
from .models import Comment, Mention


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('content', 'post', 'user', 'created_at',)
    list_filter = ('user', 'created_at', 'post', )
    search_fields = ('user__username', 'content')


@admin.register(Mention)
class MentionAdmin(admin.ModelAdmin):
    list_display = ( "comment", "reply", 'user', 'created_at',)
    list_filter = ('user', 'created_at', "comment", "reply")
    search_fields = ('user__username', 'comment__content', 'reply_content')

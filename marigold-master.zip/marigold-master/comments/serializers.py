from rest_flex_fields import FlexFieldsModelSerializer
from rest_framework import serializers

from posts.models import Post
from users.models import User
from .models import Comment, Mention


class UserInfoSerializer(FlexFieldsModelSerializer):
    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "picture"]


class HasRepliesCustomField(serializers.BooleanField):
    def to_representation(self, comment):
        return comment.replies.exists()


class CommentSerializer(FlexFieldsModelSerializer):
    detailed_user_info = UserInfoSerializer(read_only=True, source="user")
    has_replies = HasRepliesCustomField(read_only=True, source='*')

    class Meta:
        model = Comment
        fields = '__all__'


class MentionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mention
        fields = '__all__'

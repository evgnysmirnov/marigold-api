POST_MEDIA_TYPES = (
    ("Video", "video"),
    ("Image", "image"),
    ("Audio", "audio"),
)

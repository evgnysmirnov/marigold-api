from django.db import models

from MariGoldAPI.abstract.base_models import BaseModel
from cases.models import Case
from comments.models import Comment
from posts.constants import POST_MEDIA_TYPES
from posts.utils import media_file_path
from users.models import User


class Post(BaseModel):
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="posts")
    authors = models.ManyToManyField(User, related_name='authors', blank=True)
    participants = models.ManyToManyField(User, related_name='participants', blank=True)
    caption = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    likes = models.ManyToManyField(User, related_name='liked_posts', blank=True)
    dislikes = models.ManyToManyField(User, related_name='disliked_posts', blank=True)

    def __str__(self):
        return f"Post by {self.case.name} on {self.created_at}"

    @property
    def comments_count(self):
        return self.related_comments.count()


class PostMedia(BaseModel):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='media')
    media_file = models.FileField(blank=False, upload_to=media_file_path)
    media_type = models.CharField(choices=POST_MEDIA_TYPES, blank=False)

    def __str__(self):
        return f"Media from {self.post}"

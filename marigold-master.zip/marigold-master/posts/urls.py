# urls.py

from django.urls import path
from .views import PostDetails, PostsList, PostMediaDetails, PostMediaList, PostLikeView, PostDisLikeView

urlpatterns = [
    path('posts/', PostsList.as_view(), name='post-list'),
    path('posts/<int:pk>/', PostDetails.as_view(), name='post-details'),
    path('like-post/<str:pk>/', PostLikeView.as_view(), name='post-like-action'),
    path('dislike-post/<str:pk>/', PostDisLikeView.as_view(), name='post-dislike-action'),
    path('post_media/<str:post_id>/', PostMediaList.as_view(), name='post-media-list'),
    path('post_media/<str:pk>/', PostMediaDetails.as_view(), name='post-media-details'),
]

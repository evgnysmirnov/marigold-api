from django.contrib import admin

from .models import Post, PostMedia


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('case', 'caption', 'created_at')
    list_filter = ('participants', 'case', 'created_at')
    search_fields = ('participants__username', 'caption')



@admin.register(PostMedia)
class PostMediaAdmin(admin.ModelAdmin):
    list_display = ('post', 'media_type', 'media_file')
    list_filter = ('post__id', 'media_type')
    search_fields = ('post__id', 'media_type', 'media_file')

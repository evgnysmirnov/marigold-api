def media_file_path(instance, filename):
    return "posts_media/{}/{}/{}".format(instance.media_type, instance.id, filename)
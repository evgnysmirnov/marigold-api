from django_filters import rest_framework as filters
from rest_framework import generics
from rest_framework import permissions
from rest_framework.filters import SearchFilter, OrderingFilter

from MariGoldAPI.abstract.logging import LoggingViewMixin
from posts.models import Post, Case, PostMedia
from posts.serializers import PostSerializer, PostMediaSerializer, PostLikeSerializer, PostDisLikeSerializer


class PostsList(LoggingViewMixin, generics.ListCreateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    search_fields = ["caption", ]
    ordering_fields = ("created_at", "likes", "dislikes", "comments",)
    ordering = ("created_at",)
    filterset_fields = ["caption", "case", "authors", "participants", "likes", "dislikes"]

    model = Post
    queryset = model.objects.all()
    serializer_class = PostSerializer


class PostDetails(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = Post
    queryset = model.objects.all()
    serializer_class = PostSerializer


class PostMediaList(generics.ListCreateAPIView):
    lookup_field = "post_id"
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = PostMedia
    serializer_class = PostMediaSerializer

    def get_queryset(self):
        post_id = self.kwargs['post_id']
        return PostMedia.objects.filter(post_id=post_id)


class PostMediaDetails(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = PostMedia
    queryset = model.objects.all()
    serializer_class = PostMediaSerializer


class PostLikeView(generics.UpdateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    model = Post
    queryset = model.objects.all()
    serializer_class = PostLikeSerializer


class PostDisLikeView(generics.UpdateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    model = Post
    queryset = model.objects.all()

    serializer_class = PostDisLikeSerializer

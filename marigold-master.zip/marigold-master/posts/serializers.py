from rest_framework import serializers

from cases.models import Case
from users.models import User
from .models import Post, PostMedia
from rest_flex_fields import FlexFieldsModelSerializer


class PostMediaSerializer(FlexFieldsModelSerializer):
    class Meta:
        model = PostMedia
        fields = '__all__'


class UserShortInfoInfoSerializer(FlexFieldsModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "first_name", "last_name", "picture"]


class CaseBaseRelatedSerializer(FlexFieldsModelSerializer):
    class Meta:
        model = Case
        fields = ["id", "name"]


class PostSerializer(FlexFieldsModelSerializer):
    media = PostMediaSerializer(read_only=True, many=True)
    case_info = CaseBaseRelatedSerializer(source='case', read_only=True)
    likes = serializers.SerializerMethodField()
    dislikes = serializers.SerializerMethodField()
    comments = serializers.IntegerField(source='comments_count')

    class Meta:
        model = Post
        fields = ["id", "media", "case_info", "caption", "likes", "dislikes", "comments", "created_at"]

    def get_likes(self, instance):
        return instance.likes.count()

    def get_dislikes(self, instance):
        return instance.dislikes.count()


class PostParticipantsCustomField(serializers.RelatedField):
    def to_representation(self, case):
        participants = [UserShortInfoInfoSerializer(participant).data for post in case.posts.all() for participant in
                        post.participants.all()]
        return participants


class PostAuthorsCustomField(serializers.RelatedField):
    def to_representation(self, case):
        authors = [UserShortInfoInfoSerializer(authors).data for post in case.posts.all() for authors in
                   post.authors.all()]
        return authors


class PostLikeSerializer(FlexFieldsModelSerializer):
    class Meta:
        model = Post
        fields = []

    def update(self, instance, validated_data):
        if isinstance(self.context.get("request").user, User):
            instance.dislikes.remove(self.context.get("request").user)
            instance.likes.add(self.context.get("request").user)
            instance.save()
        return instance


class PostDisLikeSerializer(FlexFieldsModelSerializer):
    class Meta:
        model = Post
        fields = []

    def update(self, instance, validated_data):
        if isinstance(self.context.get("request").user, User):
            instance.likes.remove(self.context.get("request").user)
            instance.dislikes.add(self.context.get("request").user)
            instance.save()
        return instance

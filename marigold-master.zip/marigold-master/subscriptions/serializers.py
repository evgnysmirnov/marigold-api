from abc import ABC

from rest_framework import serializers

from subscriptions.models import Subscription


class SubscriptionSerializer(serializers.ModelSerializer):
    class Meta:
        fields = "__all__"
        model = Subscription
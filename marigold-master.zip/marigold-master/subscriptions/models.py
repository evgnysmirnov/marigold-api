from django.db import models

from MariGoldAPI.abstract.base_models import BaseModel
from cases.models import Case
from users.models import User


class Subscription(BaseModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="users")
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="subscriptions")

    class Meta:
        unique_together = ('user', 'case')

    def __str__(self):
        return f"{self.user.username} subscribed to {self.case.name}"
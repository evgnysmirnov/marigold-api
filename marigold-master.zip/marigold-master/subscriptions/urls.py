from django.urls import path

from subscriptions.views import SubscriptionList, SubscriptionDetails, UnsubscribeView

urlpatterns = [
    path('subscriptions/', SubscriptionList.as_view(), name='subscriptions-list'),
    path('subscriptions/<str:pk>/', SubscriptionDetails.as_view(), name='subscription-details'),
    path('unsubscribe/', UnsubscribeView.as_view(), name='unsubscribe'),
]
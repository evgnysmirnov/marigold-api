from rest_framework.response import Response
from django_filters import rest_framework as filters
from rest_framework import generics, permissions, status
from rest_framework.filters import SearchFilter, OrderingFilter

from subscriptions.models import Subscription
from subscriptions.serializers import SubscriptionSerializer


class SubscriptionList(generics.ListCreateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    ordering = ("created_at",)
    filterset_fields = ["user", "case"]
    model = Subscription
    queryset = model.objects.all()
    serializer_class = SubscriptionSerializer


class SubscriptionDetails(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = Subscription
    queryset = model.objects.all()
    serializer_class = SubscriptionSerializer


class UnsubscribeView(generics.DestroyAPIView):
    """
    Unsibscribe view:
    Delete request required the body ex.\n
    {
    "user":"4bebf8e6-7327-4da9-bef2-fc7042850222",
    "case":"9bb4c9f1-47da-4340-89f8-d3d89ab2bfee"
    }
    """
    permission_classes = [
        permissions.AllowAny
    ]
    model = Subscription
    queryset = model.objects.all()
    serializer_class = SubscriptionSerializer

    def destroy(self, request, *args, **kwargs):
        data = request.data
        try:
            subscription = Subscription.objects.get(user__id=data["user"], case__id=data["case"])
            subscription.delete()
        except Subscription.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        return Response({"message":"OK"}, status=status.HTTP_204_NO_CONTENT)


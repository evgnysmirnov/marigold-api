# urls.py

from django.urls import path

from cases.views import CasesList, CaseDetails

urlpatterns = [
    path('cases/', CasesList.as_view(), name='cases-list'),
    path('cases/<str:pk>/', CaseDetails.as_view(), name='case-details'),
]

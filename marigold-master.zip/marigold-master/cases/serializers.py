from rest_flex_fields import FlexFieldsModelSerializer
from rest_framework import serializers

from cases.models import Case
from posts.serializers import PostParticipantsCustomField, PostAuthorsCustomField
from users.models import User


class CaseTotalSubsCountCustomField(serializers.IntegerField):
    def to_representation(self, case):
        return case.subscriptions.count()


class CaseTotalLikesCountCustomField(serializers.IntegerField):
    def to_representation(self, case):
        likes = 0
        for post in case.posts.all():
            likes += post.likes.count()
        return likes


class CaseTotalDisLikesCountCustomField(serializers.IntegerField):
    def to_representation(self, case):
        dislikes = 0
        for post in case.posts.all():
            dislikes += post.dislikes.count()
        return dislikes


class CaseIsCurrentUserSubscribedCustomField(serializers.IntegerField):
    def to_representation(self, case):
        if isinstance(self.context.get("request").user, User):
            return case.subscriptions.all().filter(user=self.context.get("request").user).exists()
        else:
            return False


class CaseTotalPostsCountCustomField(serializers.BooleanField):
    def to_representation(self, case):

        return case.posts.count()


class CaseSerializer(FlexFieldsModelSerializer):
    all_authors = PostAuthorsCustomField(read_only=True, source="*")
    all_participants = PostParticipantsCustomField(read_only=True, source="*")
    is_current_user_subscribed = CaseIsCurrentUserSubscribedCustomField(read_only=True, source='*')

    class Meta:
        model = Case
        fields = '__all__'


class CaseDetailsSerializer(FlexFieldsModelSerializer):
    all_authors = PostAuthorsCustomField(read_only=True, source="*")
    all_participants = PostParticipantsCustomField(read_only=True, source="*")
    subscriptions = CaseTotalSubsCountCustomField(read_only=True, source='*')
    total_likes = CaseTotalLikesCountCustomField(read_only=True, source='*')
    total_dislikes = CaseTotalDisLikesCountCustomField(read_only=True, source='*')
    total_posts = CaseTotalPostsCountCustomField(read_only=True, source='*')
    is_current_user_subscribed = CaseIsCurrentUserSubscribedCustomField(read_only=True, source='*')
    class Meta:
        model = Case
        fields = '__all__'

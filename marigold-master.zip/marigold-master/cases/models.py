from django.db import models

from MariGoldAPI.abstract.base_models import BaseModel


class Case(BaseModel):
    name = models.CharField(max_length=20, blank=False)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name}"


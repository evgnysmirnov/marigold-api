from django.contrib import admin

from cases.models import Case


@admin.register(Case)
class CaseAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'created_at')
    list_filter = ('name', 'description', 'created_at')
    search_fields = ('name', 'description', 'created_at')


from django_filters import rest_framework as filters
from rest_framework import generics
from rest_framework import permissions
from rest_framework.filters import SearchFilter, OrderingFilter

from cases.models import Case
from cases.serializers import CaseSerializer, CaseDetailsSerializer


class CasesList(generics.ListCreateAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    search_fields = ["description", ]
    ordering_fields = ("created_at", "posts",)
    ordering = ("created_at",)
    filterset_fields = ["posts", "subscriptions__user"]

    model = Case
    queryset = model.objects.all()
    serializer_class = CaseSerializer


class CaseDetails(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [
        permissions.AllowAny
    ]
    filter_backends = [filters.DjangoFilterBackend, SearchFilter, OrderingFilter]
    model = Case
    queryset = model.objects.all()
    serializer_class = CaseDetailsSerializer

import facebook
from django.contrib.admin.models import LogEntry
from django.contrib.auth import authenticate
from django.contrib.auth.hashers import make_password
from django.utils.translation import gettext_lazy as _
from rest_framework import exceptions
from rest_framework import serializers

from users.models import User, PasswordRecoveryKey, ReportComplaint
from .constants import CN_NAME
from .emails import email_password_recovery
from .apple_auth import AppleUserAuth, AppleAuthExetion
from google.oauth2 import id_token
from google.auth.transport import requests


class BaseUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True, style={"input_type": "password"}, min_length=6, max_length=128
    )

    def validate_password(self, value):
        value = make_password(value)
        return value


class UserSerializer(BaseUserSerializer):
    subscriptions = serializers.SerializerMethodField()
    likes = serializers.SerializerMethodField()
    dislikes = serializers.SerializerMethodField()
    notifications = serializers.BooleanField(default=True, read_only=True, required=False)

    class Meta:
        model = User
        fields = [
            "id",
            "email",
            "password",
            "first_name",
            "last_name",
            "picture",
            "is_staff",
            "is_superuser",
            "subscriptions",
            "likes",
            "dislikes",
            "is_active",
            "notifications",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "is_superuser", "created_at", "updated_at"]

    @staticmethod
    def get_subscriptions(instance):
        return instance.users.count()

    @staticmethod
    def get_likes(instance):
        return instance.liked_posts.count()

    @staticmethod
    def get_dislikes(instance):
        return instance.disliked_posts.count()


class AuthTokenSerializer(serializers.Serializer):
    email = serializers.EmailField(write_only=True, required=True)
    password = serializers.CharField(
        style={"input_type": "password"}, min_length=3, max_length=128, write_only=True
    )
    token = serializers.ReadOnlyField()
    user = serializers.ReadOnlyField()

    def validate(self, attrs):
        email = attrs.get("email")
        password = attrs.get("password")

        if email and password:
            user = authenticate(username=email, password=password)
            if user:
                if not user.is_active:
                    msg = _(
                        "User account is inactive. Please use the activation mail in your inbox to activate account"
                    )
                    raise exceptions.AuthenticationFailed(msg, "account_inactive")
            else:
                msg = _("Unable to log in with provided credentials")
                raise exceptions.ParseError(msg)
        else:
            msg = _("Please provide email and password")
            raise exceptions.ParseError(msg)

        attrs["user"] = user
        return attrs


class PasswordChangeSerializer(serializers.Serializer):
    old_password = serializers.CharField(
        style={"input_type": "password"},
        min_length=6,
        max_length=128,
        required=True,
        write_only=True,
    )
    new_password = serializers.CharField(
        style={"input_type": "password"},
        min_length=6,
        max_length=128,
        required=True,
        write_only=True,
    )

    user = serializers.PrimaryKeyRelatedField(
        read_only=True,
        default=serializers.CreateOnlyDefault(serializers.CurrentUserDefault()),
    )

    def validate(self, attrs):
        old_password = attrs.get("old_password")
        new_password = attrs.get("new_password")
        user = self.context.get("request", None).user
        if old_password and new_password:
            if not user.check_password(old_password):
                msg = _("The old password is not correct")
                raise exceptions.PermissionDenied(msg, "old_password_invalid")
        return attrs

    def create(self, validated_data):
        user = validated_data.get("user")
        new_password = validated_data.get("new_password")
        user.set_password(new_password)
        user.save()
        return user


class PasswordRecoverySerializer(serializers.Serializer):
    email = serializers.EmailField(required=True)

    def validate(self, attrs):
        email = attrs.get("email")
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            msg = _("User with this {email} email not found".format(email=email))
            raise exceptions.NotFound(msg)
        attrs["user"] = user
        return attrs

    def create(self, validated_data):
        user = validated_data["user"]
        email = validated_data["email"]
        key = PasswordRecoveryKey.objects.create(user=user).key
        email_password_recovery(user, key)
        return {"email": email}


class PasswordRecoveryConfirmationSerializer(serializers.Serializer):
    password = serializers.CharField(
        style={"input_type": "password"},
        min_length=6,
        max_length=128,
        write_only=True,
        required=True,
    )
    key = serializers.UUIDField(write_only=True, required=True)
    user = serializers.PrimaryKeyRelatedField(
        read_only=True,
        default=serializers.CreateOnlyDefault(serializers.CurrentUserDefault()),
    )

    def validate(self, attrs):
        key = attrs.get("key")
        try:
            user = PasswordRecoveryKey.objects.get(key=key).user
            attrs["user"] = user
        except PasswordRecoveryKey.DoesNotExist:
            raise serializers.ValidationError({"key": "Key invalid"})
        return attrs

    def create(self, validated_data):
        key = validated_data.get("key")
        user = validated_data.get("user")
        password = validated_data["password"]
        user.set_password(password)
        user.save()
        user.password_recovery_keys.filter(key=key).delete()
        return user


class SNAuthTokenSerializer(serializers.Serializer):
    sn_name = serializers.ChoiceField(choices=CN_NAME, label="Social network name", write_only=True, required=True)
    sn_token = serializers.CharField(label="Social network token", write_only=True, required=True)
    email = serializers.EmailField(label="Email", write_only=True, required=False, default=None)
    token = serializers.ReadOnlyField()
    user = serializers.ReadOnlyField()

    def get_fb_profile(self, sn_token):
        try:
            graph = facebook.GraphAPI(sn_token)
            return graph.get_object("me", fields='id,email,first_name,last_name,picture.width(300).height(300)')
        except facebook.GraphAPIError:
            msg = _('Token is invalid')
            raise exceptions.ParseError(msg, 'invalid_sn_token')

    def get_google_plus_profile(self, sn_token):
        try:
            idinfo = id_token.verify_oauth2_token(sn_token, requests.Request())
            userid = idinfo['sub']
            return idinfo
        except ValueError:
            msg = _('Token is invalid')
            raise exceptions.ParseError(msg, 'invalid_sn_token')

    def get_apple_profile(self, sn_token):
        try:
            aua = AppleUserAuth()
            return aua.retrieve_user(sn_token)
        except AppleAuthExetion as e:
            raise exceptions.ParseError(str(e), 'invalid_sn_token')

    def validate(self, attrs):
        sn_name = attrs.get('sn_name')
        sn_token = attrs.get('sn_token')

        if sn_name and sn_token:
            sn_profile_valid = {}

            if sn_name == "facebook":
                sn_profile = self.get_fb_profile(sn_token)
                sn_profile_valid['id'] = sn_profile.get('id')
                sn_profile_valid['email'] = sn_profile.get('email')
                sn_profile_valid['first_name'] = sn_profile.get('first_name')
                sn_profile_valid['last_name'] = sn_profile.get('last_name')
                sn_profile_valid['avatar'] = sn_profile['picture']['data'].get('url')

            if sn_name == "google":
                sn_profile = self.get_google_plus_profile(sn_token)
                sn_profile_valid['id'] = sn_profile.get('sub')
                sn_profile_valid['email'] = sn_profile.get('email')
                sn_profile_valid['first_name'] = sn_profile.get('given_name')
                sn_profile_valid['last_name'] = sn_profile.get('family_name')
                sn_profile_valid['avatar'] = sn_profile['picture']
                if sn_profile_valid['email'] is None:
                    msg = _('Please provide email')
                    raise exceptions.ParseError(msg)
                if sn_profile_valid['avatar'] is not None:
                    url = sn_profile_valid['avatar'].split('?')[0]
                    sn_profile_valid['avatar'] = "{}{}".format(url, '?sz=300')
            if sn_name == "apple":
                sn_profile = self.get_apple_profile(sn_token)
                sn_profile_valid['id'] = sn_profile.id
                sn_profile_valid['email'] = sn_profile.email
        else:
            msg = _('Please provide social network name and social network token')
            raise exceptions.ParseError(msg)

        attrs['sn_profile'] = sn_profile_valid
        return attrs


class LogEntrySerializer(serializers.ModelSerializer):
    content_type = serializers.CharField(read_only=True, source='content_type.model')

    class Meta:
        model = LogEntry
        fields = "__all__"


class ReportComplaintSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportComplaint
        fields = "__all__"

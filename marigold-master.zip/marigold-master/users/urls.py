from django.urls import path
from users import views

urlpatterns = [
    path("auth/token/", views.AuthToken.as_view(), name="auth-token"),
    path("users/", views.UserList.as_view(), name="user-list"),
    path("users/<uuid:pk>/", views.UserDetails.as_view(), name="user-details"),
    path(
        "users/password-change/",
        views.PasswordChange.as_view(),
        name="user-password-change",
    ),
    path(
        "users/password-recovery/",
        views.PasswordRecovery.as_view(),
        name="user-password-recovery",
    ),
    path(
        "users/password-recovery-confirmation/",
        views.PasswordRecoveryConfirmation.as_view(),
        name="user-password-recovery-confirmation",
    ),
    path(
        "logs_entry/",
        views.LogEntryView.as_view(),
        name="logs-entry",
    ),
    path("social-auth-token", views.SNAuthToken.as_view(),
         name="social-network-auth",
    ),
    path("personal-profile", views.UserPersonalProfile.as_view(),
         name='personal-profile/'
    ),
    path("reports", views.ReportComplaintView.as_view(),
         name='reports-complaint/'
    ),

]

from django.core.files import File
from PIL import Image
import requests
from io import BytesIO


def user_picture_path(instance, filename):
    return "images/user_pictures/{}/{}".format(instance.id, filename)

def get_image_from_url(url):
    response = requests.get(url)
    img = Image.open(BytesIO(response.content))
    return File(img.fp)
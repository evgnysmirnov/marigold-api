from django.conf import settings


def email_user_welcome(user, temporary_password):
    data = {
        "temporary_password": temporary_password,
        "redirect_link": settings.SITE_URL,
    }
    user.email_user(
        template="welcome-email", data=data, from_email="noreply@test.com"
    )


def email_password_recovery(user, key):
    data = {
        "email": user.email,
        "confirmation_link": "{}{}?key={}".format(
            settings.SITE_URL, "/users/password-recovery-confirmation", key
        ),
    }
    user.email_user(
        template="password-recovery", data=data, from_email="noreply@test.com"
    )

def email_create_account_using_social_network(user, sn_name, random_password):
    data = {
        'first_name': user.first_name,
        'last_name': user.last_name,
        'sn_name': sn_name,
        'password': random_password,
    }
    user.email_user(template="create-account-using-social-network", data=data, from_email="noreply@test.com")


def email_create_account_using_facebook_no_email(user, key, action_type):
    data = {
        'first_name': user.first_name,
        'last_name': user.last_name,
        'confirmation_link': "{}{}?key={}&a={}".format(settings.SITE_URL, "/accounts/confirmations", key,
                                                       action_type)
    }
    user.email_user(template="create-account-using-facebook-no-email", data=data, from_email="noreply@test.com")


def email_confirm_facebook(user, key, action_type):
    data = {
        'first_name': user.first_name,
        'last_name': user.last_name,
        'confirmation_link': "{}{}?key={}&action_type={}".format(settings.SITE_URL, "/accounts/confirmations", key,
                                                                 action_type)
    }
    user.email_user(template="confirm-facebook", data=data, from_email="noreply@test.com")


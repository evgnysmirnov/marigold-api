CN_NAME = (
    ('facebook', 'facebook'),
    ('google', 'google'),
    ('apple', 'apple')
)

ACCTION_TYPE = (
    ('base_activation', 'base_activation'),
    ('sn_activation', 'sn_activation'),
    ('sn_and_base_activation', 'sn_and_base_activation'),
    ('password_recovery', 'password_recovery')
)
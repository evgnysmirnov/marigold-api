import jwt
import requests
from time import time
import json

from jwt.algorithms import RSAAlgorithm


class AppleUser:

    def __init__(self, apple_id, email=None):
        self.id = apple_id
        self.email = email
        self.full_user = False

        if email is not None:
            self.full_user = True

    def __repr__(self):
        return "<AppleUser {}>".format(self.id)


class AppleAuthExetion(Exception):
    pass


class AppleUserAuth:
    APPLE_PUBLIC_KEY_URL = "https://appleid.apple.com/auth/keys"
    APPLE_APP_ID = "handiscover.Market-Place-IOS"
    APPLE_PUBLIC_KEY = None
    APPLE_KEY_CACHE_EXP = 60 * 60 * 24
    APPLE_LAST_KEY_FETCH = 0

    def _fetch_apple_public_key(self, kid):
        if (self.APPLE_LAST_KEY_FETCH + self.APPLE_KEY_CACHE_EXP) < int(time()) or self.APPLE_PUBLIC_KEY is None:
            key_payload = requests.get(self.APPLE_PUBLIC_KEY_URL).json()
            key = json.dumps([key for key in key_payload["keys"] if key['kid'] == kid][0])
            self.APPLE_PUBLIC_KEY = RSAAlgorithm.from_jwk(key)
            self.APPLE_LAST_KEY_FETCH = int(time())
        return self.APPLE_PUBLIC_KEY

    def _decode_apple_user_token(self, apple_user_token):
        kid = jwt.get_unverified_header(apple_user_token).get('kid')
        public_key = self._fetch_apple_public_key(kid)
        try:
            token = jwt.decode(apple_user_token, public_key, algorithms=["RS256"], audience=self.APPLE_APP_ID)
        except jwt.ExpiredSignatureError as e:
            raise AppleAuthExetion("That token has expired")
        except jwt.InvalidAudienceError as e:
            raise AppleAuthExetion("That token's audience did not match")
        except AppleAuthExetion as e:
            print(e)
            raise AppleAuthExetion("An unexpected error occoured")

        return token

    def retrieve_user(self, user_token):
        token = self._decode_apple_user_token(user_token)
        apple_user = AppleUser(token["sub"], token.get("email", None))
        return apple_user

import random

from django.contrib.admin.models import LogEntry
from django.contrib.auth.models import update_last_login
from rest_framework import generics
from rest_framework import permissions
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from django.utils.translation import gettext_lazy as _
from users.emails import email_user_welcome, email_confirm_facebook, email_create_account_using_facebook_no_email, \
    email_create_account_using_social_network
from .models import User, SocialAccounts, AccountsConfirmation, ReportComplaint
from .serializers import (
    AuthTokenSerializer,
    PasswordChangeSerializer,
    PasswordRecoverySerializer,
    PasswordRecoveryConfirmationSerializer, UserSerializer, SNAuthTokenSerializer, LogEntrySerializer,
    ReportComplaintSerializer,
)
from .utils import get_image_from_url


class UserList(generics.ListCreateAPIView):
    permission_classes = [permissions.AllowAny]
    model = User
    queryset = model.objects.all()

    def get_serializer_class(self):
        return UserSerializer

    def perform_create(self, serializer):
        serializer.save()
        password = serializer.validated_data.get("password")
        email_user_welcome(self.request.user, password)


class UserDetails(generics.RetrieveUpdateAPIView):
    permission_classes = [permissions.AllowAny]
    model = User
    queryset = model.objects.all()

    def get_serializer_class(self):
        return UserSerializer


class UserPersonalProfile(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = UserSerializer
    queryset = User.objects.all()

    def get_object(self):
        return self.request.user


class AuthToken(generics.GenericAPIView):
    """
    After you get the token. For clients to authenticate, the token key should be included in the Authorization HTTP header.
    The key should be prefixed by the string literal "Token", with whitespace separating the two strings.
    For example: Authorization: Token 9944b09199c62bcf9418ad846dd0e4bbdfc6ee4b
    """

    permission_classes = (permissions.AllowAny,)
    serializer_class = AuthTokenSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        token, created = Token.objects.get_or_create(user=user)
        update_last_login(None, user)
        return Response({"token": token.key, "user": user.id}, status.HTTP_201_CREATED)


class PasswordChange(generics.CreateAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = PasswordChangeSerializer

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

    def perform_create(self, serializer):
        user = serializer.validated_data.get("user", self.request.user)
        serializer.save(user=user)


class PasswordRecovery(generics.CreateAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = PasswordRecoverySerializer


class PasswordRecoveryConfirmation(generics.CreateAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = PasswordRecoveryConfirmationSerializer


class SNAuthToken(generics.GenericAPIView):
    """
    After you get the token. For clients to authenticate, the token key should be included in the Authorization HTTP header.
    The key should be prefixed by the string literal "Token", with whitespace separating the two strings.
    For example: Authorization: Token 9944b09199c62bcf9418ad846dd0e4bbdfc6ee4b
    """
    permission_classes = (permissions.AllowAny,)
    serializer_class = SNAuthTokenSerializer

    def sn_account_inactive(self):
        msg = _('Social network account is inactive')
        raise Exception(msg, 'sn_account_inactive')

    def __fasebook_auth(self, validated_data):
        sn_profile = validated_data['sn_profile']

        try:
            # SN account exist, just sing in user if SN account is acctive
            sa_object = SocialAccounts.objects.get(sn_name=validated_data['sn_name'],
                                                   sn_id=sn_profile['id'])
            user = sa_object.user
            if sa_object.is_active is True:
                return self.create_token(user)
            else:
                return self.sn_account_inactive()
        except SocialAccounts.DoesNotExist:
            if sn_profile['email'] is not None:
                try:
                    # SN account create and activete exist user
                    # User have email in the FB
                    user = User.objects.get(email__iexact=sn_profile['email'])
                    user.is_active = True
                    user.save()
                    SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                                  sn_name=validated_data['sn_name'],
                                                  user=user)
                    return self.create_token(user)
                except User.DoesNotExist:
                    # SN account and user create. Activete user
                    # User have email in the FB
                    random_password = User.objects.make_random_password(6)

                    user = User.objects.create_user(email=sn_profile['email'],
                                                    password=random_password,
                                                    first_name=sn_profile['first_name'],
                                                    last_name=sn_profile['last_name'],
                                                    is_active=True)
                    if sn_profile['avatar'] is not None:
                        user.picture.save("{}.jpg".format(user.id), get_image_from_url(sn_profile['picture']),
                                          save=True)

                    SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                                  sn_name=validated_data['sn_name'],
                                                  user=user)
                    email_create_account_using_social_network(user=user,
                                                              sn_name=validated_data['sn_name'],
                                                              random_password=random_password)
                    return self.create_token(user)
            else:
                if validated_data['email'] is not None:
                    try:
                        # SN account create. Sending email with confirmation of integration FB
                        # User don't have email in the FB
                        user = User.objects.get(email__iexact=validated_data['email'])
                        sn_account = SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                                                   sn_name=validated_data['sn_name'],
                                                                   user=user,
                                                                   is_active=False)

                        key = AccountsConfirmation.objects.create(account_id=sn_account.id,
                                                                  type='sn_activation').key
                        email_confirm_facebook(user=user, key=key, action_type='sn_activation')
                        return self.sn_account_inactive()
                    except User.DoesNotExist:
                        # SN account and user create. Sending email with confirmation of create a basic account
                        # User don't have email in the FB
                        random_password = User.objects.make_random_password(6)
                        user = User.objects.create_user(email=validated_data['email'],
                                                        password=random_password,
                                                        first_name=sn_profile['first_name'],
                                                        last_name=sn_profile['last_name'])
                        if sn_profile['avatar'] is not None:
                            user.picture.save("{}.jpg".format(user.id), get_image_from_url(sn_profile['picture']),
                                              save=True)
                        sn_account = SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                                                   sn_name=validated_data['sn_name'],
                                                                   user=user,
                                                                   is_active=False)
                        key = AccountsConfirmation.objects.create(account_id=sn_account.id,
                                                                  type='sn_and_base_activation').key
                        email_create_account_using_facebook_no_email(user=user, key=key,
                                                                     action_type="sn_and_base_activation")
                        return self.sn_account_inactive()
                else:
                    msg = _(
                        'This social network is not connected to the user. Please provide a email address and send the request again')
                    raise Exception(msg)

    def create_token(self, user):
        token, created = Token.objects.get_or_create(user=user)
        update_last_login(None, user)
        return Response({'token': token.key, 'user': user.id}, status.HTTP_201_CREATED)

    def __google_plus_auth(self, validated_data):
        sn_profile = validated_data['sn_profile']
        try:
            # SN account exist, just sing in user
            sa_object = SocialAccounts.objects.get(sn_name=validated_data['sn_name'],
                                                   sn_id=sn_profile['id'])
            user = sa_object.user
            return self.create_token(user)
        except SocialAccounts.DoesNotExist:
            try:
                # SN account create and activete exist user
                user = User.objects.get(email__iexact=sn_profile['email'])
                user.is_active = True
                user.save()
                SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                              sn_name=validated_data['sn_name'],
                                              user=user)
                return self.create_token(user)
            except User.DoesNotExist:
                # SN account and user create. Activete user
                random_password = User.objects.make_random_password(6)
                user = User.objects.create_user(email=sn_profile['email'],
                                                password=random_password,
                                                first_name=sn_profile['first_name'],
                                                last_name=sn_profile['last_name'],
                                                is_active=True)
                if sn_profile['avatar'] is not None:
                    user.picture.save("{}.jpg".format(user.id), get_image_from_url(sn_profile['avatar']),
                                      save=True)
                SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                              sn_name=validated_data['sn_name'],
                                              user=user)
                # email_create_account_using_social_network(user=user, sn_name=validated_data['sn_name'],
                #                                           random_password=random_password)
                return self.create_token(user)

    def __apple_auth(self, validated_data):
        sn_profile = validated_data['sn_profile']
        try:
            # SN account exist, just sing in user
            sa_object = SocialAccounts.objects.get(sn_name=validated_data['sn_name'],
                                                   sn_id=sn_profile['id'])
            user = sa_object.user
            return self.create_token(user)
        except SocialAccounts.DoesNotExist:
            try:
                # SN account create and activete exist user
                user = User.objects.get(email__iexact=sn_profile['email'])
                user.is_active = True
                user.save()
                SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                              sn_name=validated_data['sn_name'],
                                              user=user)
                return self.create_token(user)
            except User.DoesNotExist:
                # SN account and user create. Activete user
                random_password = User.objects.make_random_password(6)
                user = User.objects.create_user(email=sn_profile['email'],
                                                password=random_password,
                                                is_active=True)
                SocialAccounts.objects.create(sn_id=sn_profile['id'],
                                              sn_name=validated_data['sn_name'],
                                              user=user)
                # email_create_account_using_social_network(user=user, sn_name=validated_data['sn_name'],
                #                                           random_password=random_password)
                return self.create_token(user)

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        if serializer.validated_data['sn_name'] == "facebook":
            return self.__fasebook_auth(serializer.validated_data)
        elif serializer.validated_data['sn_name'] == "google":
            return self.__google_plus_auth(serializer.validated_data)
        elif serializer.validated_data['sn_name'] == "apple":
            return self.__apple_auth(serializer.validated_data)


class LogEntryView(generics.ListAPIView):
    permission_classes = [
    ]
    model = LogEntry
    queryset = model.objects.all()
    serializer_class = LogEntrySerializer
    filterset_fields = ['content_type__model', 'user',
                        'action_time', 'object_id',
                        'object_repr', 'action_flag',
                        'id']


class ReportComplaintView(generics.ListCreateAPIView):
    permission_classes = [
    ]
    model = ReportComplaint
    queryset = model.objects.all()
    serializer_class = ReportComplaintSerializer
    ordering = ("created_at",)
    filterset_fields = [ 'user',]

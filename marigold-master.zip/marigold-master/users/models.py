import random
import uuid

from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import AbstractUser
from MariGoldAPI.abstract.base_models import BaseModel
from users.constants import CN_NAME, ACCTION_TYPE
from users.utils import user_picture_path
from django.core.mail import EmailMessage
from MariGoldAPI.celery import celery_app


class UserManager(BaseUserManager):
    def _create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError("The given email must be set")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        if not user.username:
            user.username = f"user_{str(random.randint(0, 99999999))}",
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password, **extra_fields):
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self._create_user(email, password, **extra_fields)


class User(AbstractUser, BaseModel):
    date_joined = None
    email = models.EmailField(
        max_length=100,
        unique=True,
        error_messages={"unique": _("A user with that email already exists")},
    )
    picture = models.ImageField(blank=True, null=True, upload_to=user_picture_path)

    class Meta:
        db_table = "users"

    def __str__(self):
        return self.username

    objects = UserManager()

    EMAIL_FIELD = "email"
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    @staticmethod
    def email_send(to, template, data=None, from_email=None, bcc=None, subject=None):
        message = EmailMessage(
            subject=subject, from_email=from_email, to=[to], bcc=bcc or []
        )
        data = data or {}
        data["sent_to"] = to
        message.template_id = template
        message.merge_global_data = data
        message.send()

    @staticmethod
    @celery_app.task
    def celery_email_send(
            to, template, data=None, from_email=None, bcc=None, subject=None
    ):
        User.email_send(
            to, template, data=data, from_email=from_email, bcc=bcc, subject=subject
        )

    def email_user(self, template, data=None, from_email=None, bcc=None, subject=None):
        pass
        # User.celery_email_send.delay(
        #     self.email, template, data, from_email, bcc, subject
        # )


class PasswordRecoveryKey(BaseModel):
    key = models.UUIDField(default=uuid.uuid4, blank=True)
    user = models.ForeignKey(
        User, related_name="password_recovery_keys", on_delete=models.CASCADE
    )

    class Meta:
        db_table = "password_recovery_keys"


class SocialAccounts(models.Model):
    id = models.UUIDField(primary_key=True, unique=True, default=uuid.uuid4, editable=False)
    sn_name = models.CharField(choices=CN_NAME, max_length=20, blank=False)
    sn_id = models.CharField(blank=False, max_length=50, unique=True)
    user = models.ForeignKey("users.User", related_name='sn_accounts', on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True, blank=True)
    updated_date = models.DateTimeField(auto_now=True, blank=True)

    class Meta:
        db_table = "social_accounts"
        unique_together = (("sn_name", "sn_id", "user"),)

class AccountsConfirmation(models.Model):
    id = models.UUIDField(primary_key=True, unique=True, default=uuid.uuid4, editable=False)
    key = models.UUIDField(default=uuid.uuid4, blank=True)
    account_id = models.UUIDField(blank=False)
    type = models.CharField(max_length=50, choices=ACCTION_TYPE)
    created_date = models.DateTimeField(auto_now_add=True, blank=True)
    updated_date = models.DateTimeField(auto_now=True, blank=True)

    class Meta:
        db_table = "accounts_confirmation"


class ReportComplaint(BaseModel):
    user = models.ForeignKey("users.User", related_name='reports', on_delete=models.CASCADE)
    details = models.TextField(blank=False)

    def __str__(self):
        return f"Report by {self.user.username} on {self.created_at}"

    def save(self, *args, **kwargs):
        twenty_four_hours_ago = timezone.now() - timezone.timedelta(hours=24)
        if ReportComplaint.objects.filter(created_at__gte=twenty_four_hours_ago):
            raise Exception(f'User {self.user.username} already sent report in current 24 hrs. Try later')
        super(ReportComplaint, self).save(*args, **kwargs)
